import DatatablesV2 from '@/components/custom/DatatablesV2'
import AuthLayout from '@/components/layout/authLayout'
import { bookingList } from '@/data/sidebar/bookingList'
import useApi from '@/hooks/useApi'
import useUser from '@/store/useUser'
import { Button, Paper, Table } from '@mantine/core'
import { useDebouncedState } from '@mantine/hooks'
import { IconEdit, IconFileExcel } from '@tabler/icons-react'
import { getCoreRowModel, useReactTable } from '@tanstack/react-table'
import axios from 'axios'
import { useRouter } from 'next/router'
import React, { useEffect, useMemo, useState } from 'react'

Booking_list.title = "Booking List"
export default function Booking_list() {
  
  const router = useRouter()
  const { user } = useUser()

  const API = useApi()
  const API_URL = API.API_URL

  const [loadingData, setLoadingData] = useState(true)
  const [loadingOpt, setLoadingOpt] = useState(false)
  const [display, setDisplay] = useState(false)

  const [data, setData] = useState([])
  const [savedFilter, setSavedFilter] = useState({})
  const [checkedId, setCheckedId] = useState([])
  const [sorting, setSorting] = useState([{ id: "id", desc: true }]);
  const [columnFilters, setColumnFilters] = useDebouncedState([], 500);
  const [pagination, setPagination] = useState({
    pageIndex: 1,
    pageSize: 10,
  });
  const [searchParams, setSearchParams] = useDebouncedState("", 500);
  const [totalPages, setTotalPages] = useState(1);

  const columns = useMemo(() => [

    {
      accessorFn: (row) => row.id,
      id: "idRow",
      header: "Key",
      enableColumnFilter: true,
      enableSorting: true,
      cell: (info) => info.getValue(),
    },

    {
      accessorFn: (row) => row.book_date,
      id: "book_date",
      header: "Book Date",
      enableColumnFilter: true,
      enableSorting: true,
      cell: (info) => info.getValue(),
    },

    {
      accessorFn: (row) => row.id,
      id: "id",
      header: "Action",
      enableColumnFilter: true,
      enableSorting: true,
      cell: (info) => {
        let value = info.getValue()
        return (
          <div className='align-middle items-center'>
            <Button onClick={() => router.push('/employee/edit_employee/' + value)} leftSection={<IconEdit />} color='orange'> Edit</Button>
          </div>
        )
      },
    },
  ])
  const table = useReactTable({
    data,
    columns,
    filterFns: {},
    state: {
      columnFilters,
      sorting,
      pagination,
    },
    onColumnFiltersChange: setColumnFilters,
    onSortingChange: setSorting,
    onPaginationChange: setPagination,
    getCoreRowModel: getCoreRowModel(),
    manualSorting: true,
    manualFiltering: true,
    manualPagination: true,
  });

  const downloadPdf  = async() => {
    try {
      const response = await axios.get(API_URL + '/api/testing/generate_pdf', {
        responseType: "blob",
        headers : {
          Authorization : "Bearer "+user.id
        }
      });

      const url = window.URL.createObjectURL(new Blob([response.data]));
      const a = document.createElement("a");
      a.href = url;
      a.download = "PDF Sample.pdf";
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      window.URL.revokeObjectURL(url);
    } catch (error) {
      console.error("Error downloading file:", error);
    }
  }

  const downloadExcel = async () => {
    try {
      const response = await axios.get(API_URL + '/api/testing/download', {
        responseType: "blob",
        headers : {
          Authorization : "Bearer "+user.token
        }
      });

      const url = window.URL.createObjectURL(new Blob([response.data]));
      const a = document.createElement("a");
      a.href = url;
      a.download = "LargeData.xlsx";
      document.body.appendChild(a);
      a.click(); 
      document.body.removeChild(a);
      window.URL.revokeObjectURL(url);
    } catch (error) {
      console.error("Error downloading file:", error);
    }
  }

  useEffect(() => {

    const getData = async () => {
      const filterParams = !searchParams ? "" : searchParams;
      const sort =
        sorting && sorting.length > 0
          ? `${sorting[0].id},${sorting[0].desc ? "desc" : "asc"}`
          : "";
      const { data } = await axios.get(
        `${API_URL}/api/booking/booking_list?search=${filterParams}&page=${pagination.pageIndex}&limit=${pagination.pageSize}&order_by=${sort}`,
        // savedFilter,
        {
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${user.token}`,
          },
        }
      );


      setData(data.data);
      setTotalPages(data.total_pages);
      if (loadingData) {
        setLoadingData(false)
      }
      setLoadingOpt(false)
    };


    getData();
  }, [
    user.token,
    columnFilters,
    pagination.pageIndex,
    pagination.pageSize,
    sorting,
    loadingData,
    savedFilter,
    API_URL,
    searchParams,
  ]);

  return (
    <AuthLayout sidebarList={bookingList}>
      <div className='py-6'>
        <div className="max-w-full mx-auto sm:px-6 lg:px-8">
          <Paper radius="sm" mt="md" style={{ position: 'relative' }} withBorder>
            <div className="px-4 py-2 text-right space-x-2">
              {/* <Button onClick={() => router.push("/employee/add_employee")}> Add Employee</Button> */}
              {/* <Button onClick={downloadExcel}> Download Excel</Button> */}
              {/* <Button onClick={downloadPdf}> Download PDF</Button> */}
              {/* <Button onClick={() => router.push("/employee/upload_sftp")}> Upload SFTP</Button> */}
              <Button color='green' onClick={() => router.push("/booking/export")}> <IconFileExcel></IconFileExcel>  Export (Excel)</Button>
            </div>
            <div className="p-4 overflow-x-auto">
              {
                <DatatablesV2
                searchParams={searchParams}
                setSearchParams={setSearchParams}
                table={table} totalPages={totalPages} />
              }
            </div>
          </Paper>
        </div>
      </div>
    </AuthLayout>
  )

}
