import React from "react";

export default function Footer() {
  return (
    <footer className="mt-auto">
      <div className="flex justify-center bg-slate-100 text-black text-sm py-2">
        <p className="text-xs">© 2024 - SEATRIUM - PCMS MECHANICAL COMPLETION</p>
      </div>
    </footer>
  );
}
