import { IconNote, IconDownload, IconHome, IconList, IconUpload, IconChecklist, IconSubtask, IconListLetters, IconGps, IconMapPinPlus, IconAtom2, IconAtom2Filled, IconFileExcel } from "@tabler/icons-react";

export const bookingList = [
  {
    title: "list",
    href: "/booking/booking_list",
    show : true,
    active: "Dashboard",
    icon: <IconList size={18} />,
  },
  {
    title: "Export",
    href: "/booking/export",
    show : true,
    active: "Dashboard",
    icon: <IconFileExcel size={18} />,
  },
  {
    title: "EXAMPLE DROPDOWN",
    href: "",
    show : true,
    active: "Dashboard",
    icon: <IconNote size={18} />,
    child: [
      {
        title: "DROPDOWN 1",
        href: "/test31",
        show : true,
        active: "Dashboard",
        icon: <IconNote size={18} />,
      },
      {
        title: "DROPDOWN 2",
        href: "/test32",
        show : true,
        active: "Dashboard",
        icon: <IconNote size={18} />,
      },
    ],
  },
];