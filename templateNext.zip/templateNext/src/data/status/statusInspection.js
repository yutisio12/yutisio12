export const statusList = {
  0 : {
    text : "ready to Submit",
    color : "blue",
  },
  1 : {
    text : "Pending Approval QC",
    color : "orange",
  },
  2 : {
    text : "Rejected by QC",
    color : "red",
  },
  3 : {
    text : "Approved by QC",
    color : "green",
  },
  4 : {
    text : "Hold by QC",
    color : "cyan",
  },
  5 : {
    text : "Pending Approval Client",
    color : "orange",
  },
  6 : {
    text : "Rejected by Client",
    color : "red",
  },
  7 : {
    text : "Approved by Client",
    color : "green",
  }
}
