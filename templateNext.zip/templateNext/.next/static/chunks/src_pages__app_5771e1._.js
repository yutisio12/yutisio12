(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_pages__app_5771e1._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_pages__app_5771e1._.js",
  "chunks": [
    "static/chunks/node_modules_next_9cff6c._.js",
    "static/chunks/node_modules_react_1cad9b._.js",
    "static/chunks/node_modules_react-dom_cjs_react-dom_development_ab7e07.js",
    "static/chunks/node_modules_react-dom_f14d04._.js",
    "static/chunks/node_modules_crypto-js_ec5e9f._.js",
    "static/chunks/node_modules_axios_lib_9a6fdf._.js",
    "static/chunks/node_modules_@mantine_core_esm_9a7045._.js",
    "static/chunks/node_modules_c5ef55._.js",
    "static/chunks/[root of the server]__e5d77d._.js",
    "static/chunks/_94e99e._.css"
  ],
  "source": "entry"
});
