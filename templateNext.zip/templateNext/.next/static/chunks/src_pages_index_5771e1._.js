(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_pages_index_5771e1._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_pages_index_5771e1._.js",
  "chunks": [
    "static/chunks/node_modules_next_bf3d59._.js",
    "static/chunks/node_modules_react_1cad9b._.js",
    "static/chunks/node_modules_react-dom_cjs_react-dom_development_ab7e07.js",
    "static/chunks/node_modules_react-dom_f14d04._.js",
    "static/chunks/node_modules_@mantine_core_esm_5d7e7c._.js",
    "static/chunks/node_modules_@floating-ui_react_dist_dec9c2._.js",
    "static/chunks/node_modules_ef379b._.js",
    "static/chunks/[root of the server]__ef5593._.js"
  ],
  "source": "entry"
});
