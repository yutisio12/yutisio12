__turbopack_load_page_chunks__("/booking/booking_list", [
  "static/chunks/node_modules_next_8a1c4b._.js",
  "static/chunks/node_modules_react_1cad9b._.js",
  "static/chunks/node_modules_react-dom_cjs_react-dom_development_ab7e07.js",
  "static/chunks/node_modules_react-dom_f14d04._.js",
  "static/chunks/node_modules_@mantine_core_esm_9f8a75._.js",
  "static/chunks/node_modules_@tanstack_table-core_build_lib_index_mjs_301229._.js",
  "static/chunks/node_modules_@floating-ui_react_dist_dec9c2._.js",
  "static/chunks/node_modules_axios_lib_9a6fdf._.js",
  "static/chunks/node_modules_15c597._.js",
  "static/chunks/[root of the server]__ec518c._.js",
  "static/chunks/src_pages_booking_booking_list_5771e1.js",
  "static/chunks/src_pages_booking_booking_list_6eacc1.js"
])
