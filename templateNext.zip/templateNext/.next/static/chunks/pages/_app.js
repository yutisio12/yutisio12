__turbopack_load_page_chunks__("/_app", [
  "static/chunks/node_modules_next_9cff6c._.js",
  "static/chunks/node_modules_react_1cad9b._.js",
  "static/chunks/node_modules_react-dom_cjs_react-dom_development_ab7e07.js",
  "static/chunks/node_modules_react-dom_f14d04._.js",
  "static/chunks/node_modules_crypto-js_ec5e9f._.js",
  "static/chunks/node_modules_axios_lib_9a6fdf._.js",
  "static/chunks/node_modules_@mantine_core_esm_9a7045._.js",
  "static/chunks/node_modules_c5ef55._.js",
  "static/chunks/[root of the server]__e5d77d._.js",
  "static/chunks/_94e99e._.css",
  "static/chunks/src_pages__app_5771e1._.js",
  "static/chunks/src_pages__app_e5efb2._.js"
])
