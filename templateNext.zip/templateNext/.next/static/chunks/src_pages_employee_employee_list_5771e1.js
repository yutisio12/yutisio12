(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_pages_employee_employee_list_5771e1.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_pages_employee_employee_list_5771e1.js",
  "chunks": [
    "static/chunks/[root of the server]__56c609._.js",
    "static/chunks/node_modules_next_8a1c4b._.js",
    "static/chunks/node_modules_react_1cad9b._.js",
    "static/chunks/node_modules_react-dom_cjs_react-dom_development_ab7e07.js",
    "static/chunks/node_modules_react-dom_f14d04._.js",
    "static/chunks/node_modules_@mantine_core_esm_279abd._.js",
    "static/chunks/node_modules_@tanstack_table-core_build_lib_index_mjs_301229._.js",
    "static/chunks/node_modules_@floating-ui_react_dist_dec9c2._.js",
    "static/chunks/node_modules_axios_lib_9a6fdf._.js",
    "static/chunks/node_modules_adfc2c._.js"
  ],
  "source": "entry"
});
